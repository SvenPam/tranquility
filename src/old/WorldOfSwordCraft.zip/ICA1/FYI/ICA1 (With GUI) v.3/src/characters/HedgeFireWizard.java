package characters;

import javax.swing.ImageIcon;

/**
 * Represents one NPC
 * Advanced Java Programming - ICA1 
 * @author Stephen Pammenter
 * K0025970
 * Teesside University
 * Created: 14.12.11
 * @version 2
 */
public class HedgeFireWizard extends GameCharacter
{
    /**
     * A two argument constructor which intialises this character.
     * @param n The name of the character.
     * @param l The level of the character.
     */
    public HedgeFireWizard(String n, int l)
    {
       this.name = n;
       this.level = l;
       this.hp = 100 + (l * 10);
       this.attackType = DamageType.fire;
       this.weakness = DamageType.shock;
       this.dPS = level * 20;
       this.image = new ImageIcon("images/wizard.png");
    } 
}

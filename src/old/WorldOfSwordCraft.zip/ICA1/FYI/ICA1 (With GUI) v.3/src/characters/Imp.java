package characters;

import javax.swing.ImageIcon;

/**
 * Represents on  NPC
 * Advanced Java Programming - ICA1
 * @author Stephen Pammenter
 * K0025970
 * Teesside University
 * Created: 14.12.11
 * @version 3
 */
public class Imp extends GameCharacter 
{
    /**
     * A two argument constructor which intialises this character.
     * @param n The name of the character.
     * @param l The level of the character.
     */
    public Imp(String n, int l) 
    {
           this.name = n;
           this.level = l;
           this.hp = 100 + (l * 10);
           this.attackType = DamageType.frost;
           this.weakness = DamageType.melee;
           this.dPS = level * 20;
           this.image = new ImageIcon("images/imp.png");
    }  
}

package gameEngine.damageHandlers;

import characters.GameCharacter;
import characters.GameCharacter.DamageType;
import gameEngine.GameEngine;

/**
 * Handler for Melee damage.
 * Advanced Java Programming - ICA 1 
 * @author Stephen Pammenter
 * K0025970
 * Teesside University
 * Created: Dec 29, 2011
 * @version 3
 */
public class MeleeDamageHandler implements DamageHandler
{
     /**The next handler in the chain*/
    private  DamageHandler sucessor = new  NatureDamageHandler();
    /**Holds the current player of the game.*/
    private  GameCharacter player = GameEngine.getCurrentPlayer();
    /**Holds the current opponent of the current game.*/
    private GameCharacter opponent = GameEngine.getOpponent(); 
    /**
     * Method for handling an attack type. Multiplies damage if either player of opponent has a weakness to that attack type.
     * @param damageType The damage type that is being used.
     */
    @Override
    public String handleDamage(DamageType damageType)
    {
        if (damageType != DamageType.melee)
        {
            return sucessor.handleDamage(damageType);
        }
        else
        {
            String result = "You were both evenly matched";
            if (damageType == player.getWeakness())
            {
                opponent.setdPS(opponent.getDPS() * 2);
                GameEngine.setOpponent(opponent);
                result = "You have taken critical damage from Melee!";
            }
            if (damageType == opponent.getWeakness())
            {
                player.setdPS(player.getDPS() * 2);
                GameEngine.setCurrentPlayer(player);
                result = "You have done critcal Melee damage to your opponent!";
            }
            return result;
        }
    }  
}

package gameEngine.damageHandlers;

import characters.GameCharacter;
import characters.GameCharacter.DamageType;
import gameEngine.GameEngine;

/**
 * Handler for ranged damage.
 * Advanced Java Programming - ICA 1 
 * @author Stephen Pammenter
 * K0025970
 * Teesside University
 * Created: Dec 29, 2011
 * @version 2
 */
public class RangedDamageHandler implements DamageHandler
{
     /**The next handler in the chain*/
    private  DamageHandler sucessor = new ShockDamageHandler();
    /**Holds the current player of the game.*/
    private  GameCharacter player = GameEngine.getCurrentPlayer();
    /**Holds the current opponent of the current game.*/
    private GameCharacter opponent = GameEngine.getOpponent(); 
    /**
     * Method for handling an attack type. Multiplies damage if either player of opponent has a weakness to that attack type.
     * @param damageType The damage type that is being used.
     */
    @Override
    public void  handleDamage(DamageType damageType)
    {
        if (damageType != DamageType.ranged)
        {
            sucessor.handleDamage(damageType);
        }
        else
        {
            if (damageType == player.getWeakness())
            {
                opponent.setdPS(opponent.getDPS() * 2);
                GameEngine.setOpponent(opponent);
                System.out.println("You have taken critical damage from a Ranged Attack!");
            }
            if (damageType == opponent.getWeakness())
            {
                player.setdPS(player.getDPS() * 2);
                GameEngine.setCurrentPlayer(player);
                System.out.println("You have done critcal ranged damage to your opponent. They couldn't even get close!");
            }
        }
    }  
}

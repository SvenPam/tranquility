package typesOfAttack;

import characters.GameCharacter;

/**
 * Represents one type of attack.
 * Advanced Java Programming - ICA1
 * @author Stephen Pammenter
 * K0025970
 * Teesside University
 * Created: Jan 4, 2012
 * @version 4
 */
public class AimedShot extends TypeOfAttack
{
    /**
     * Triple argument constructor.
     * @param character The attacking character of this fight.
     * @param opponent The character being attacked.
     * @param playerAttacking If the character that is attacking, is the player.
     */
    public AimedShot(GameCharacter character, GameCharacter opponent, boolean playerAttacking)
    {
        super(character, opponent, playerAttacking);
        this.damage = 70;
        this.resource = 40;
        
    }
    /**
     * Sets the attacking characters base damage for this attack.
     */
    @Override
    void setDamage()
    {
        character.setdPS(damage);
    }
    /**
     * Sets this attacks type, either Damage of Time (DoT), Absorb or Effect Turn (ET).
     */
    @Override
    void setType()
    {
        System.err.println("Not implemented");
    }
    /**
     * Removes the cost of this attacks resources from the attacking player. But also adds 20 for the end of round.
     */
    @Override
    void setResource()
    {
        character.setResource(character.getResource() - resource);
        character.setResource(character.getResource() + 20);
    }
    /**
     * The attack report to inform the player.
     */
    @Override
    void setMessage()
    {
        if (playerAttacking == true)
        {
            this.message = "\n You have done " + character.getDPS() + " points of ranged damage to " + opponent.getName();
        }
        else
            this.message = "\n Your enemy " + character.getDPS() + " points of ranged damage to you"; 
    }
    /**
     * The name of this attack is returned for the button text in the fight screen.
     * @return Name of this attack.
     */
    @Override
    public String toString()
    {
        return "Aimed Shot";
    }
}

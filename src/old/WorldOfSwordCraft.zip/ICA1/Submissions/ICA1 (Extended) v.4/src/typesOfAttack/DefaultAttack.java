package typesOfAttack;

import characters.GameCharacter;

/**
 * Represents one type of attack.
 * Advanced Java Programming - ICA1
 * @author Stephen Pammenter
 * K0025970
 * Teesside University
 * Created: Jan 4, 2012
 * @version 4
 */
public class DefaultAttack extends TypeOfAttack
{
    /**
     * Triple argument constructor.
     * @param character The attacking character of this fight.
     * @param opponent The character being attacked.
     * @param playerAttacking If the character that is attacking, is the player.
     */
    public DefaultAttack(GameCharacter character, GameCharacter opponent, boolean playerAttacking)
    {
        super(character, opponent, playerAttacking);
        this.damage = 10;
        this.resource = 0;      
    }
    /**
     * Sets the attacking characters base damage for this attack.
     */
    @Override
    void setDamage()
    {
        character.setdPS(damage);
    }
    /**
     * Sets this attacks type, either Damage of Time (DoT), Absorb or Effect Turn (ET).
     */
    @Override
    void setType()
    {
        System.err.println("Not implemented");
    }
    /**
     * Removes the cost of this attacks resources from the attacking player. But also adds 20 for the end of round.
     */
    @Override
    void setResource()
    {
        character.setResource(character.getResource() - resource);
        character.setResource(character.getResource() + 50);
    }
    /**
     * The attack report to inform the player.
     */
    @Override
    void setMessage()
    {
        if (playerAttacking == true)
        {
            this.message = "\n You have done " + character.getDPS() + " points of basic " + character.getAttackType1() + " damage to " + opponent.getName() + ". It wasn't much but you got 50 resource back!";
        }
        else
            this.message = "\n Your enemy has done" + character.getDPS() + " points of basic " + character.getAttackType1() + " damage to you!"; 
        
    }
    /**
     * The name of this attack is returned for the button text in the fight screen.
     * @return Name of this attack.
     */
    @Override
    public String toString()
    {
        return "Default Attack";
    }
}

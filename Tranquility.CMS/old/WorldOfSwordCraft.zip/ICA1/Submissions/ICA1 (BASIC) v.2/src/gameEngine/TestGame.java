package gameEngine;

import characters.*;
import characters.GameCharacter;
import gameEngine.damageHandlers.FireDamageHandler;
import java.util.Scanner;

/**
 * The main class.
 * Advanced Java Programming - ICA1
 * @author Stephen Pammenter
 * K0025970
 * Teesside University
 * Created: Dec 21, 2011
 * @version 2
 */
public class TestGame
{
    //Creates a test Player called Legolas a level 1 'Fire Mage'.
      public static GameCharacter player = new Elf("Legolas", 1, GameCharacter.DamageType.ranged);
    /**
     * The main method.
     * @param args the command line arguments
     */
    public static void main(String[] args)    
    {
        //Stores the new character in the game engine.
        GameEngine.setCurrentPlayer(player);
        /**Input for While loop*/
        String done = null;
        /**Scanner for inout in while loop.*/
        Scanner input = new Scanner(System.in);
        /**The terminating condition for the while loop*/
        boolean b = false;
        //The loop to keep creating new opponents.
        while (b != true)
        {
            //Creates an opponent.
            GameCharacter opponent = GameEngine.getNewOpponent();
            //Text ouput
            System.out.println(GameEngine.getCurrentPlayer().toString() + "\n ---------------------------- \n Will now face your opponent: " + opponent.toString());
            //Creates new Handler which starts the chain.
              gameEngine.damageHandlers.DamageHandler handler = new  FireDamageHandler();
            //Passes request to Chain of Handlers.
            handler.handleDamage(player.getAttackType());
            //Method used to process fight result.
            attackMsg(GameEngine.attack(), opponent);
            //Sets DPS back to coreect ammount is changed by handler.
            player.setdPS(player.getLevel()*20);
            //User given opptunity to continue or stop.
            System.out.println("\n Fight again?");
             done = input.next(); 
            if (done.equalsIgnoreCase("n"))
            {
                b = true;
            }
        }
    }
    /**
     * Method used to create an output for the result of the attack method.
     * @param i
     */
    private static void attackMsg(int i, GameCharacter o)
    {
         switch(i)
        {
            case -1:
                System.out.println("You were killed by " + o.getName() + "!");
                break;
            case 0:
                System.out.println("You and " + o.getName() + " both leave bloodied and beaten. Its a draw!");
                break;
            case 1:
                System.out.println("You have defeted and slain "+ o.getName() + "! You have now leveled up!");
                player.setLevel(player.getLevel() + 1);
                System.out.println("You are now level " + player.getLevel());
                break;      
        }
    }
}

package gameEngine.damageHandlers;

/**
 * Represents a Damage Handler.
 * Advanced Java Programming - ICA 1
 * @author Stephen Pammenter
 * K0025970
 * Teesside University
 * Created: 29.12.11
 * @version 2
 */
public interface DamageHandler
{
    //To handle the request
    public void  handleDamage(characters.GameCharacter.DamageType damageType);
}

/**
 * Contains template pattern files for all types of attack used by the game.
 */
package typesOfAttack;

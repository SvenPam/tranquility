package typesOfAttack;

import characters.GameCharacter;

/**
 * Represents one type of attack.
 * Advanced Java Programming - ICA1
 * @author Stephen Pammenter
 * K0025970
 * Teesside University
 * Created: Jan 4, 2012
 * @version 4
 */
public class Stab extends TypeOfAttack
{
    /**
     * Triple argument constructor.
     * @param character The attacking character of this fight.
     * @param opponent The character being attacked.
     * @param playerAttacking If the character that is attacking, is the player.
     */
    public Stab(GameCharacter character, GameCharacter opponent, boolean playerAttacking)
    {
        super(character, opponent, playerAttacking);
        this.damage = 30;
        this.resource = 20;
        this.attackStyle = AttackStyle.doT;
        
    }
    /**
     * Sets the attacking characters base damage for this attack.
     */
    @Override
    void setDamage()
    {
        character.setdPS(damage);
    }
    /**
     * Sets this attacks type, either Damage of Time (DoT), Absorb or Effect Turn (ET).
     */
    @Override
    void setType()
    {
        System.err.println("Not implemented");
    }
    /**
     * Removes the cost of this attacks resources from the attacking player. But also adds 20 for the end of round.
     */
    @Override
    void setResource()
    {
        character.setResource(character.getResource() - resource);
        character.setResource(character.getResource() + 20);
    }
    /**
     * The attack report to inform the player.
     */
    @Override
    void setMessage()
    {
        if (playerAttacking == true)
        {
            this.message = "\n You have done " + character.getDPS() + " points of melee damage to " + opponent.getName();
        }
        else
            this.message = "\n Your enemy " + character.getDPS() + " points of melee damage to you"; 
    }
    /**
     * The name of this attack is returned for the button text in the fight screen.
     * @return Name of this attack.
     */
    @Override
    public String toString()
    {
        return "Stab";
    }
}

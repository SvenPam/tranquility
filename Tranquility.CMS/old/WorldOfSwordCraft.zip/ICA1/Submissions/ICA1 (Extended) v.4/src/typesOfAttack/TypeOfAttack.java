package typesOfAttack;

import characters.GameCharacter;
import gameEngine.GameEngine;
import gameEngine.damageHandlers.DamageHandler;
import gameEngine.damageHandlers.FireDamageHandler;

/**
 * Represents a template for an attack.
 * Advanced Java Programming - ICA 1
 * @author Stephen Pammenter
 * K0025970
 * Teesside University
 * Created: 03.01.12
 * @version 4
 */
public abstract class  TypeOfAttack
{
    /**The attacking character*/
    protected GameCharacter character;
    /**The character being attacked*/
    protected GameCharacter opponent;
    /**Represents if the player is the attacking character.*/
    protected Boolean playerAttacking;
    /**Holds the amount of damage being dealt.*/
    protected int damage;
    /**Hold the total resource this character has available.*/
    protected int resource;
    /**Holds a handlerMessage to be outputed to the player in th GUI*/
    protected String handlerMessage;
    /**Holds a handlerMessage to be outputed to the player in th GUI*/
    protected String message;
    /**Holds the style of attack*/
    public enum AttackStyle{
    /**Damage over Time*/
    doT,
    /**Absorbs resource*/
    absorb,
    /**Effect turn - randomly selects if an opponent misses a turn*/
    eT }
    /**Holds the attack style*/
    protected AttackStyle attackStyle;
    /**
     * Triple argument constructor.
     * @param character The attacking character of this fight.
     * @param opponent The character being attacked.
     * @param playerAttacking If the character that is attacking, is the player.
     */
    public TypeOfAttack(GameCharacter character, GameCharacter opponent, boolean playerAttacking)
    {
        this.character = character;
        this.opponent = opponent;
        this.playerAttacking = playerAttacking;
    }
    /**
     * Attack is a template method, which calls all the necessary methods to perform all the attack procedures.
     */
    public final void attack(GameCharacter.DamageType damagetype)
    {
         setDamage();
         setType();
         setResource();
         callHandler(damagetype);
         setHealth();
         setPlayers();
         setMessage();    
    }
    /**
     * setDamage will be supplied to all subclasses who shall override it.
     */
    abstract void setDamage(); 
    /**
     * 
     * setType will be supplied to all subclasses who shall override it.
     */
    abstract void setType();
    /**
     * setResource will be supplied to all subclasses who shall override it.
     */
    abstract void setResource();
    /**
     * Acessor method to return resource cost of attack.
     * @return resource The cost of the attack to the player.
     */
    public int getResource()
    {
        return resource;
    }
    /**
     * Passes the attack type, and starts the chain of handlers to deal with an attack type.
     */
    void callHandler(GameCharacter.DamageType damageType)
    {
        DamageHandler handler = new FireDamageHandler();
        handlerMessage = handler.handleDamage(damageType);
    }
    /**
     * Removes damage from the attacked characters health.
     */
    void setHealth()
     {
         opponent.setHp(opponent.getHp() - character.getDPS());
     }
    /**
     * Depending on whether the character attacking is the player or not will depend on whether which way the player and opponent is reset with their new attributes.
     */
    void setPlayers()
    {
        if (playerAttacking == true)
        {
            GameEngine.setCurrentPlayer(character);
            GameEngine.setOpponent(opponent);
        }
        else
        {
            GameEngine.setCurrentPlayer(opponent);
            GameEngine.setOpponent(character);
        
        }
    }
    /**
     * The message created by the handler.
     * @return The critical attack message.
     */
    public String getHandlerMessage()
    {
        return handlerMessage;
    }  
    /**
     * setMessage will be supplied to all subclasses who shall override it.
     */
    abstract void setMessage();
    /**
     * Returns a battle handlerMessage for the player.
     * @return handlerMessage Information on what just happened from the players action. 
     */
    public String getMessage()
    {
        return message;
    }
    /**
     * Accessor method to retrieve damage.
     * @return The base damage of this attack.
     */
    public int getDamage()
    {
        return damage;
    }
    /**
     * Updates players, opponents, and playerAttacking.
     * @param character The attacking character.
     * @param opponent The character being attacked.
     * @param playerAttacking  If the player is the attacking player, true if so.
     */
    public void update(GameCharacter character, GameCharacter opponent, boolean playerAttacking)
    {
        this.character = character;
        this.opponent = opponent;
        this.playerAttacking = playerAttacking;
    }
}

package characters;

import javax.swing.ImageIcon;
import typesOfAttack.FireBolt;
import typesOfAttack.Inferno;

/**
 * Represents on  NPC
 * Advanced Java Programming - ICA1
 * @author Stephen Pammenter
 * K0025970
 * Teesside University
 * Created: 14.12.11
 * @version 4
 */
public class RedPriest extends GameCharacter 
{
    /**
     * A two argument constructor which intialises this character.
     * @param n The name of the character.
     * @param l The level of the character.
     */
    public RedPriest(String n, int l) 
    {
           this.name = n;
           this.level = l;
           this.hp = 150 + (l * 10);
           this.resource = 100 + (l*10);
           this.attackType1 = DamageType.fire;
           this.weakness1 = DamageType.shadow;
           this.dPS = level * 20;
           this.image = new ImageIcon("images/redPriest.png");
           this.attack1 = new FireBolt(this, null, false);
           this.attack2 = new Inferno(this, null, false);
    }  
    
    
}

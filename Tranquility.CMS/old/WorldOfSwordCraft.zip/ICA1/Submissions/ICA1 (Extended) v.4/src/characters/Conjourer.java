package characters;

import javax.swing.ImageIcon;

/**
 * Represents on  NPC
 * Advanced Java Programming - ICA1
 * @author Stephen Pammenter
 * K0025970
 * Teesside University
 * Created: 14.12.11
 * @version 4
 */
public class Conjourer extends GameCharacter 
{
    /**
     * A two argument constructor which intialises this character.
     * @param n The name of the character.
     * @param l The level of the character.
     */
    public Conjourer(String n, int l) 
    {
           this.name = n;
           this.level = l;
           this.hp = 200 + (l * 10);
           this.resource = 100 + (l*10);
           this.attackType1 = DamageType.shadow;
           this.weakness1 = DamageType.nature;
           this.dPS = level * 20;
           this.image = new ImageIcon("images/wizardShadow.png");
    }  
}

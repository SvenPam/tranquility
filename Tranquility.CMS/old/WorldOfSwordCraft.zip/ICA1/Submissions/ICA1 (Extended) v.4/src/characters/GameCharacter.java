package characters;

import javax.swing.ImageIcon;
import typesOfAttack.TypeOfAttack;

/**
 * Represents one race of character, can be either a player or an NPC.
 * Advanced Java Programming - ICA1
 * @author Stephen Pammenter
 * K0025970
 * Teesside University
 * Created: 14.12.11
 * @version 4
 */
public abstract class GameCharacter 
{
    /**The name of the character*/
    protected String name;
    /** The level of this character*/
    protected int level;
    /**The health points of this character*/
    protected int hp;
    /**The amount of resources a character has to use.*/
    protected int resource;
    /**Hold the types of attack*/
    public enum DamageType{/**A close up physical attack.*/melee, 
    /**A ranged physical ranged attack from a bow.*/ranged,
    /**Fiery magic attack.*/fire,
    /**Freezing magic attack.*/frost,
    /**Electrical magic attack.*/shock,
    /**Dark magic of the dead.*/shadow,
    /**Poisonous damage.*/nature};
    /** This characters first attack type.*/
    protected DamageType attackType1;
    /** This characters second attack type.*/
    protected DamageType attackType2;
    /** The weakness1 of this character.*/
    protected DamageType weakness1;
    /** The weakness1 of this character.*/
    protected DamageType weakness2;
    /**The damage output of this character.*/
    protected int dPS;
    /**Holds the image for this character.*/
    protected ImageIcon image;
    /**A string that holds the URL of an image*/
    protected String imgURI;
    /**Used by NPC, its first attack type*/
    protected typesOfAttack.TypeOfAttack attack1;
     /**Used by NPC, its second attack type*/
    protected typesOfAttack.TypeOfAttack attack2;
    /**
     * Returns the DPS of this character.
     * @return dPS The damage per second of this character.
     */
    public int getDPS()
    {
        return dPS;
    }
    /**
     * Changes the current value of DPS for this character.
     * @param dPS The new damage per second of this character.
     */
    public void setdPS(int dPS)
    {
        this.dPS = dPS;
    }
    /**
     * Sets the first attack type of the player.
     * @param attackType1 The attack type of this player. 
     */
    public void setAttackType1(DamageType attackType1)
    {
        this.attackType1 = attackType1;
        setWeakness1AndImage(attackType1);
    }
    /**
     * Gets the first attack type of this character.
     * @return attackType1 The first attack type.
     */
    public DamageType getAttackType1()
    {
        return attackType1;
    }   
    /**
     * Sets the first attack type of the player.
     * @param attackType2 The player first attack type.
     */
    public void setAttackType2(DamageType attackType2)
    {
        this.attackType2 = attackType2;
    }
    /**
     * Gets the second attack type of this character.
     * @return attackType2 The second attack type.
     */
    public DamageType getAttackType2()
    {
        return attackType2;
    }
    /**
     * The health points of this character.
     * @return hp This characters health.
     */
    public int getHp()
    {
        return hp;
    }
    /**
     * Changes the variable of the health of this character.
     * @param hp The new maximum health of this character.
     */
    public void setHp(int hp)
    {
        this.hp = hp;
    }
    /**
     * Gets the current level of this character.
     * @return level The current level of this character.
     */
    public int getLevel()
    {
        return level;
    }
    /**
     * Changes the current variable of this characters health.
     * @param level The level of this character. 
     */
    public void setLevel(int level)
    {
        this.level = level;
        setHp(100 + (level*10));
        setResource(200 + (level*10));
    }
    /**
     * The name of thus character.
     * @return name This characters name.
     */
    public String getName()
    {
        return name;
    }
    /**
     * Changes the variable that is this characters name.
     * @param name The new name of this character.
     */
    public void setName(String name)
    {
        this.name = name;
    }
    /**
     * Gets the variable of this characters weakness1.
     * @return The weakness of this player.
     */
    public DamageType getWeakness()
    {
        return weakness1;
    }
    /**
     * Sets both the Weakness of the character and also sets the class image.
     * @param attackType1 
     */
    public void setWeakness1AndImage(DamageType attackType1)
    {
        String temp = getImgURI();
        switch (this.attackType1)
       {
           case fire:
               this.weakness1 = DamageType.frost;
               temp += "FireMage";
               setImage(temp);
               break;
           case frost:
               this.weakness1 = DamageType.fire;
                temp += "FrostMage";
               setImage(temp);
               break;
           case melee:
               this.weakness1 = DamageType.ranged;
               temp += "Warrior";
               setImage(temp);
               break;
           case ranged:
               this.weakness1 = DamageType.nature;
               temp += "Hunter";
               setImage(temp);
               break;
           case shadow:
               this.weakness1 = DamageType.shock;
               temp += "Warlock";
               setImage(temp);
               break;
           case shock:
               this.weakness1 = DamageType.shadow;  
               temp += "StormMage";
               setImage(temp);
               break;
           case nature:
               this.weakness1 = DamageType.melee;
               temp += "Rogue";
               setImage(temp);
               break;
       }
    }

    /**
     * Sets the 2nd weakness of the player.
     * @param attackType2 The second attack type. 
     */
    public void setWeakness2(DamageType attackType2)
    {
        
        switch (this.attackType2)
       {
           case fire:
               this.weakness2 = DamageType.frost;
               break;
           case frost:
               this.weakness2 = DamageType.fire;
               break;
           case melee:
               this.weakness2 = DamageType.ranged;
               break;
           case ranged:
               this.weakness2 = DamageType.nature;
               break;
           case shadow:
               this.weakness2 = DamageType.shock;
               break;
           case shock:
               this.weakness2 = DamageType.shadow;
               break;
           case nature:
               this.weakness2 = DamageType.melee;
               break;
       }
    }
    

    public ImageIcon getImage()
    {
        return image;
    }

    public void setImage(String imgURI)
    {
        ImageIcon img = new ImageIcon(imgURI + ".png");
        this.image = img;
    }

    
    public String getImgURI()
    {
        return imgURI;
    }

    public int getResource()
    {
        return resource;
    }

    public void setResource(int resource)
    {
        this.resource = resource;
    }

    public TypeOfAttack getAttack1()
    {
        return attack1;
    }

    public TypeOfAttack getAttack2()
    {
        return attack2;
    }

   
    
    
    /**
     * Creates a string of all this characters information.
     * @return A description of this character.
     */
    @Override
    public String toString()
    {
        return  name + "\n Level " + level + "\n HP:" + hp + "\n Attack Type " + attackType1 + "\n Weakness " + weakness1 + "\n dPS: " + dPS;
    }
         
}

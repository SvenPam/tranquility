package gameEngine;

import characters.*;
import java.util.Random;
import typesOfAttack.DefaultAttack;
/**
 * Performs all the game mechanics and holds current fighting characters.
 * Advanced Java Programming - ICA1 
 * @author Stephen Pammenter
 * K0025970
 * Teesside University
 * Created: 02.11.11
 * Version 4
 */
public class GameEngine 
{
    /**Holds an instance of the current player.*/
    private static GameCharacter currentPlayer;
    /**Holds an instance of an NPC*/
    private static GameCharacter opponent;
    /**Random number generator.*/
    private static Random generator = new Random();
    /**Holds the opponent damage report*/
    private static String damageReport;
    /**Holds the opponent crit report*/
    private static String critReport;
    /**
     * Gets the current player.
     * @return currentPlayer
     */
    public static GameCharacter getCurrentPlayer() 
    {
        return currentPlayer;
    }
    /**
     * Sets the current player.
     * @param currentPlayer The current player.
     */
    public static void setCurrentPlayer(GameCharacter currentPlayer) 
    {
        GameEngine.currentPlayer = currentPlayer;
    }
    /**
     * Updates the variable holding the current opponent.
     * @param opponent The new opponent.
     */
    public static void setOpponent(GameCharacter opponent)
    {
        GameEngine.opponent = opponent;
    }
    /**
     * Gets the current opponent and returns it.
     * @return The current opponent.
     */
    public static GameCharacter getOpponent()
    {
        return opponent;
    }
    
    /**
     * Randomly selects an opponent for the player  to fight.
     * @return The opponent for the player to fight.
     */
    public static GameCharacter getNewOpponent()
    {
        int randomNum = generator.nextInt( 8 );
        randomNum = 7;
        switch(randomNum)
        {
            case 0:
                opponent = new Troll("Cave Troll", currentPlayer.getLevel());
                break;
            case 1: 
                opponent = new Bandit("Bandit Smuggler", currentPlayer.getLevel());
                break;
            case 2:
                opponent = new Conjourer("Bandit Conjourer", currentPlayer.getLevel());
                break;
            case 3:
                opponent= new HedgeFireWizard("Hedge Fire Wizard", currentPlayer.getLevel());
                break;
            case 4:
                opponent= new IceWraith("Ice Wraith", currentPlayer.getLevel());
                break;
            case 5:
                opponent= new Imp("Imp", currentPlayer.getLevel());
                break;
            case 6:
                opponent= new FlameAtronach("Flame Attronach", currentPlayer.getLevel());
                break;
            case 7:
                opponent= new RedPriest("Red Priest", currentPlayer.getLevel());
                break;
        }
        return opponent;
    }
    /**
     * Sets the 'battle' messages to be displayed to the user.
     * @param damage Damage done by players.
     * @param crit Critical hits.
     */
    public static void setMessages(String damage, String crit)
    {
        damageReport= damage;
        critReport = crit;
    }
    /**
     * Acessor method for handler report.
     * @return critReport The message created by handlers.
     */
    public static String getCritReport()
    {
        return critReport;
    }
    /**
     * Accessor method for the damage report made by the typesOfAttack.
     * @return damageReport The damage done report to be outputted to the user.
     */
    public static String getDamageReport()
    {
        return damageReport;
    }
    /**
     * The AI for the opponent's attack.
     */
    public static void opponentAttack()
    {
         typesOfAttack.TypeOfAttack attack1 = opponent.getAttack1();
         attack1.update(opponent, currentPlayer, false);
         typesOfAttack.TypeOfAttack attack2 = opponent.getAttack2();
         attack2.update(opponent, currentPlayer, false);
        int randomNum = generator.nextInt( 1 );
         switch(randomNum)
        {
            case 0:
                if (attack1.getResource() <= opponent.getResource())
                {
                    attack1.attack(opponent.getAttackType1());
                    setMessages(attack1.getMessage(), attack1.getHandlerMessage());
                }
                else
                    attack1 = new DefaultAttack(opponent, currentPlayer, false);
                    attack1.attack(opponent.getAttackType1());
                    setMessages(attack1.getMessage(), attack1.getHandlerMessage());
                break;
            case 1:
                if (attack2.getResource() <= opponent.getResource())
                {
                    attack2.attack(opponent.getAttackType1());
                    setMessages(attack1.getMessage(), attack1.getHandlerMessage());
                }
                else if (attack1.getResource() <= opponent.getResource())
                {
                    attack1.attack(opponent.getAttackType1());
                    setMessages(attack1.getMessage(), attack1.getHandlerMessage());
                }
                else
                    attack1 = new DefaultAttack(opponent, currentPlayer, false);
                    attack1.attack(opponent.getAttackType1());
                    setMessages(attack1.getMessage(), attack1.getHandlerMessage());
                break;
        }
         
    }
    /**
     * Level's up the chracter.
     */
    public static void levelUp()
    {
        currentPlayer.setLevel(currentPlayer.getLevel() + 1);
    }
}

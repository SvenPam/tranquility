package characters;

/**
 * Represents one race of character, can be either a player or an NPC.
 * Advanced Java Programming - ICA1
 * @author Stephen Pammenter
 * K0025970
 * Teesside University
 * Created: 14.12.11
 * @version 1
 */
public abstract class GameCharacter 
{
    /**The name of the character*/
    protected String name;
    /** The level of this character*/
    protected int level;
    /**The health points of this character*/
    protected int hp;
    /**Hold the types of attack*/
    public enum DamageType{/**A close up physical attack.*/melee, 
    /**A ranged physical ranged attack from a bow.*/ranged,
    /**Fiery magic attack.*/fire,
    /**Freezing magic attack.*/frost,
    /**Electrical magic attack.*/shock,
    /**Dark magic of the dead.*/shadow,
    /**Poisonous damage.*/nature};
    /** This characters attack type.*/
    protected DamageType attackType;
    /** The weakness of this character.*/
    protected DamageType weakness;
    /**The damage output of this character.*/
    protected int dPS;
    /**
     * Returns the DPS of this character.
     * @return dPS The damage per second of this character.
     */
    public int getDPS()
    {
        return dPS;
    }
    /**
     * Changes the current value of DPS for this character.
     * @param dPS The new damage per second of this character.
     */
    public void setdPS(int dPS)
    {
        this.dPS = dPS;
    }
    /**
     * Gets the attack type of this character.
     * @return attactType The type of attack that this character uses.
     */
    public DamageType getAttackType()
    {
        return attackType;
    }
    /**
     * The health points of this character.
     * @return hp This characters health.
     */
    public int getHp()
    {
        return hp;
    }
    /**
     * Changes the variable of the health of this character.
     * @param hp The new maximum health of this character.
     */
    public void setHp(int hp)
    {
        this.hp = hp;
    }
    /**
     * Gets the current level of this character.
     * @return level The current level of this character.
     */
    public int getLevel()
    {
        return level;
    }
    /**
     * Changes the current variable of this characters health.
     * @param level The level of this character. 
     */
    public void setLevel(int level)
    {
        this.level = level;
    }
    /**
     * The name of thus character.
     * @return name This characters name.
     */
    public String getName()
    {
        return name;
    }
    /**
     * Changes the variable that is this characters name.
     * @param name The new name of this character.
     */
    public void setName(String name)
    {
        this.name = name;
    }
    /**
     * Gets the variable of this characters weakness.
     * @return 
     */
    public DamageType getWeakness()
    {
        return weakness;
    }
    /**
     * Creates a string of all this characters information.
     * @return A description of this character.
     */
    @Override
    public String toString()
    {
        return  name + "\n Level " + level + "\n HP:" + hp + "\n Attack Type " + attackType + "\n Weakness " + weakness + "\n dPS: " + dPS;
    }
         
}

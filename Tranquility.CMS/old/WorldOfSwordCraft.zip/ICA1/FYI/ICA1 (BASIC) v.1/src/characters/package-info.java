/**
 * Contains all character class files.
 */
package characters;

package characters;
/**
 * Represents one playable character.
 * Advanced Java Programming - ICA1 
 * @author Stephen Pammenter
 * K0025970
 * Teesside University
 * Created: 14.12.11
 * @version 1
 */
public class Troll extends GameCharacter
{
    /**
     * A two argument constructor which intialises this character.
     * @param n The name of the character.
     * @param l The level of the character.
     */
    public Troll(String n, int l)
    {
       this.name = n;
       this.level = l;
       this.hp = 100 + (l * 10);
       this.attackType = DamageType.melee;
       this.weakness = DamageType.fire;
       this.dPS = level * 20;
    } 
}

package characters;
/**
 * Represents one playable character.
 * Advanced Java Programming - ICA1 
 * @author Stephen Pammenter
 * K0025970
 * Teesside University
 * Created: 14.12.11
 * @version 3
 */
public class Orc extends GameCharacter 
{
    /**
     * A triple argument constructor which intilises this character.
     * @param n The name of this player.
     * @param l The intial level of this player.
     * @param a The damage/class of this player.
     */
    public Orc(String n, int l, DamageType a) 
    {
       this.name = n;
       this.level = l;
       this.hp = 100 + (l * 10);
       this.attackType = a;
       this.dPS = level * 20;
       this.imgURI = "images/orc";
       switch (this.attackType)
       {
           case fire:
               this.weakness = DamageType.frost;
               break;
           case frost:
               this.weakness = DamageType.fire;
               break;
           case melee:
               this.weakness = DamageType.ranged;
               break;
           case ranged:
               this.weakness = DamageType.nature;
               break;
           case shadow:
               this.weakness = DamageType.shock;
               break;
           case shock:
               this.weakness = DamageType.shadow;   
               break;
           case nature:
               this.weakness = DamageType.melee;
               break;
       }
    } 
}

package gameEngine;

import characters.*;
import java.util.Random;
/**
 * Performs all the game mechanics and holds current fighting characters.
 * Advanced Java Programming - ICA1 
 * @author Stephen Pammenter
 * K0025970
 * Teesside University
 * Created: 02.11.11
 * Version 3
 */
public class GameEngine 
{
    /**Holds an instance of the current player.*/
    private static GameCharacter currentPlayer;
    /**Holds an instance of an NPC*/
    private static GameCharacter opponent;
    /**
     * Gets the current player.
     * @return currentPlayer
     */
    public static GameCharacter getCurrentPlayer() 
    {
        return currentPlayer;
    }
    /**
     * Sets the current player.
     * @param currentPlayer The current player.
     */
    public static void setCurrentPlayer(GameCharacter currentPlayer) 
    {
        GameEngine.currentPlayer = currentPlayer;
    }
    /**
     * Updates the variable holding the current opponent.
     * @param opponent The new opponent.
     */
    public static void setOpponent(GameCharacter opponent)
    {
        GameEngine.opponent = opponent;
    }
    /**
     * Gets the current opponent and returns it.
     * @return 
     */
    public static GameCharacter getOpponent()
    {
        return opponent;
    }
    
    /**
     * Randomly selects an opponent for the player  to fight.
     * @return The opponent for the player to fight.
     */
    public static GameCharacter getNewOpponent()
    {
        Random generator = new Random();
        int randomNum = generator.nextInt( 8 );
        switch(randomNum)
        {
            case 0:
                opponent = new Troll("Cave Troll", currentPlayer.getLevel());
                break;
            case 1: 
                opponent = new Bandit("Bandit Smuggler", currentPlayer.getLevel());
                break;
            case 2:
                opponent = new Conjourer("Bandit Conjourer", currentPlayer.getLevel());
                break;
            case 3:
                opponent= new HedgeFireWizard("Hedge Fire Wizard", currentPlayer.getLevel());
                break;
            case 4:
                opponent= new IceWraith("Ice Wraith", currentPlayer.getLevel());
                break;
            case 5:
                opponent= new Imp("Imp", currentPlayer.getLevel());
                break;
            case 6:
                opponent= new FlameAtronach("Flame Attronach", currentPlayer.getLevel());
                break;
            case 7:
                opponent= new RedPriest("Red Priest", currentPlayer.getLevel());
                break;
        }
        return opponent;
    }
    /**
     * Returns an int depending on the outcome of battle. Based on the DPS output of each character.
     * @return Fight outcome. 1 = win -1 = Loss and 0 = Draw.
     */
    private static int i;
    public static String attack()
    {
        if (opponent.getDPS() < currentPlayer.getDPS())
        {
            currentPlayer.setLevel(currentPlayer.getLevel() + 1);
            currentPlayer.setdPS(currentPlayer.getLevel() * 20);
            return "Won";
        }
        else if (opponent.getDPS() == currentPlayer.getDPS())
        {
                return "Draw";
        }
        else 
        {
            opponent.setdPS(opponent.getLevel() * 20);
            return  "Loss";  
        }
                       
    }     
    
}

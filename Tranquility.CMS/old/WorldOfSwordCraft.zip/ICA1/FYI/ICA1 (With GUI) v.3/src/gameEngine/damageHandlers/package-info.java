/**
 * Package that contains all the handlers for the game.
 */
package gameEngine.damageHandlers;

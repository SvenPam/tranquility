package gameEngine;

import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 * The main class which tests the game mechanics and creates the JFrame which holds all other JPanels.
 * Advanced Java Programming - ICA 
 * @author Stephen Pammenter
 * K0025970
 * Teesside University
 * Created: Dec 30, 2011
 * @version 3
 */
public class TestGame
{
    //Creates new JFrame
    private static JFrame application = new JFrame ("World of Swordcraft");
    private static JPanel current = new MainScreen();
    /**
     * The main method.
     * @param args the command line arguments
     */
    public static void main(String[] args)    
    {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try
        {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels())
            {
                if ("Nimbus".equals(info.getName()))
                {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex)
        {
            java.util.logging.Logger.getLogger(MainScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex)
        {
            java.util.logging.Logger.getLogger(MainScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex)
        {
            java.util.logging.Logger.getLogger(MainScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex)
        {
            java.util.logging.Logger.getLogger(MainScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        
        application.add(current);
        application.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
        //Center JApplication.
        java.awt.Dimension screenSize = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
        application.setBounds((screenSize.width-410)/2, (screenSize.height-330)/2, 410, 330);    
        application.pack();
        application.setVisible(true);  
        
    }
    
    public static void nextWindow(JPanel next)
    {
        current.setVisible(false);
        application.remove(current);
        current = next;
        current.setVisible(true);
        application.add(current);
        application.pack();
    }
}
